# lambdatest_cypress10_smartUI
A basic sample code for Cypress 10 SmartUI setup on LambdaTest.

Steps:
1) Clone/download the repo.
2) Run the following command to install dependencies> npm i
3) Set LambdaTest username and access key in lambdatest-config.json (OR, set LT_USERNAME and LT_ACCESS_KEY in environment variables)
4) run the command> lambdatest-cypress run
